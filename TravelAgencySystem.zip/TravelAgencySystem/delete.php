<?php
require_once 'mongodb/src/functions.php';


$manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
$bulkWrite = new MongoDB\Driver\BulkWrite;

if (isset($_GET['id'])) {
    
    $id = $_GET['id']; 

    try {
       
        $bulkWrite->delete(['_id' => new MongoDB\BSON\ObjectId($id)]);
        $manager->executeBulkWrite('atoz.bookings', $bulkWrite);

        echo "<script>
                alert('Record deleted successfully!');
                window.location.href = 'index.php';
              </script>";
    } catch (MongoDB\Driver\Exception\Exception $e) {
        echo "<script>
                alert('Error: " . $e->getMessage() . "');
                window.location.href = 'index.php';
              </script>";
    }
}
?>
