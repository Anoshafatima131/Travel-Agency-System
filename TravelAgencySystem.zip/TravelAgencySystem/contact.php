
<?php
require_once 'mongodb/src/functions.php';


$manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
$bulkWrite = new MongoDB\Driver\BulkWrite;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $phone = htmlspecialchars($_POST['phone']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    
    $document = [
        'name' => $name,
        'phone' => $phone,
        'email' => $email,
        'message' => $message,
        'created_at' => new MongoDB\BSON\UTCDateTime()  
    ];

    
    try {
        $bulkWrite->insert($document);
        $manager->executeBulkWrite('atoz.contact_us', $bulkWrite);

        echo "<script>
                alert('Message sent successfully!');
                window.location.href = 'index.php';
              </script>";
    } catch (MongoDB\Driver\Exception\Exception $e) {
        echo "<script>
                alert('Error: " . $e->getMessage() . "');
                window.location.href = 'index.php';
              </script>";
    }
}
?>
