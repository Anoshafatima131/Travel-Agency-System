<?php
require_once 'mongodb/src/functions.php';

// MongoDB connection
$manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");

// Query for the "bookings" collection
$query = new MongoDB\Driver\Query([]);  // Empty query to fetch all documents

try {
    $cursor = $manager->executeQuery('atoz.bookings', $query);  // Query the 'atoz' DB and 'bookings' collection
    
    $documents = iterator_to_array($cursor);  // Convert the cursor to an array to avoid re-iteration
    
    var_dump($documents);  // Display all documents in one go
} catch (MongoDB\Driver\Exception\Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

